To test cudppRand using cudpp_testrig, download the rand test datafiles from http://code.google.com/p/cudpp/downloads/detail?name=cudpp_rand_datafiles.zip
