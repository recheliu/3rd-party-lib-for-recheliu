function c = clamp(m,M,a);

   c = max(m,min(M,a));

return;
