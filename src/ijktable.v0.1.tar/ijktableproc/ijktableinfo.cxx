/// \file ijktableinfo.cxx
/// print isosurface table information

/*
  IJK: Isosurface Jeneration Code
  Copyright (C) 2006, 2003, 2001 Rephael Wenger

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public License
  (LGPL) as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

#include <stdio.h> 


#include "ijktable.h"

using namespace IJKTABLE;
using namespace std;

typedef float COORD_TYPE;

// global variables
const char * isotable_filename;
bool print_stat = false;
bool print_poly = false;
vector<int> entry;

// routines
void parse_command_line(int argc, char **argv);
void usage_error();

int main(int argc, char **argv)
{
  ISOSURFACE_TABLE isotable(3);

  parse_command_line(argc, argv);

  try {
    ifstream isotable_file(isotable_filename, ios::in);

    if (!isotable_file) {
      cerr << "Unable to read isosurface table file "
	   << isotable_filename << "." << endl;
      exit(30);
    };

    isotable.ReadText(isotable_file);
  }
  catch (ISOSURFACE_TABLE_ERROR error) {
    cerr << "Error reading isosurface table from " 
	 << isotable_filename << "." << endl;
    cerr << error.Msg() << endl;
    cerr << "Exiting." << endl;
    exit(35);
  };

  if (print_poly) {
    int numv = isotable.Polyhedron().NumVertices();
    cout << "Number of polyhedron vertices = " << numv << "." << endl;
    cout << "Vertices:" << endl;
    for (int iv = 0; iv < numv; iv++) {
      cout << "  " << setw(3) << iv << ":";
      for (int ic = 0; ic < isotable.Polyhedron().Dimension(); ic++) {
	cout << "  " << isotable.Polyhedron().VertexCoord(iv, ic);
      };
      cout << endl;
    };
    cout << endl;

    int nume = isotable.Polyhedron().NumEdges();
    cout << "Number of polyhedron edges = " << nume << "." << endl;
    cout << "Edges: " << endl;
    for (int ie = 0; ie < nume; ie++) {
      cout << "  " << setw(3) << ie << ":";
      for (int j = 0; j < 2; j++) {
	cout << "  " << isotable.Polyhedron().EdgeEndpoint(ie, j);
      };
      cout << endl;
    };
    cout << endl;
  };

  for (int i = 0; i < entry.size(); i++) {
    int it = entry[i];
    if (it < 0 || it >= isotable.NumTableEntries()) {
      cerr << "Error.  Entry " << it
	   << " is not in range [0.." << isotable.NumTableEntries()-1
	   << "]." << endl;
      continue;
    };

    cout << "Table Entry: " << it << endl;
    cout << "  Number of simplices = "
	 << isotable.NumSimplices(it) << "." << endl;
    cout << "  Simplex vertices:" << endl;
    for (int is = 0; is < isotable.NumSimplices(it); is++) {
      cout << "  ";
      for (int iv = 0; iv < isotable.NumVerticesPerSimplex(); iv++) {
	cout << "  " << int(isotable.SimplexVertex(it, is, iv));
      };
      cout << endl;
    };
    cout << endl;
  };

  if (print_stat) {

    long max_s = 0;
    long total_s = 0;
    for (long i = 0; i < isotable.NumTableEntries(); i++) {
      long n = isotable.NumSimplices(i);
      if (max_s < n) max_s = n;
      total_s += n;
    };
    double avg_s = ((double) total_s)/((double) isotable.NumTableEntries());

    cout << "Dimension = " << isotable.Dimension() << endl;
    cout << "Polyhedron:" << endl;
    cout << "  # Vertices = " << isotable.Polyhedron().NumVertices() << endl;
    cout << "  # Edges = " << isotable.Polyhedron().NumEdges() << endl;
    cout << "  # Facets = " << isotable.Polyhedron().NumFacets() << endl;
    cout << "Table:" << endl;
    cout << "  # Entries = " << isotable.NumTableEntries() << endl;
    cout << "  Max # simplices per entry = " << max_s << endl;
    cout << "  Avg # simplices per entry = " << avg_s << endl;
  };
}

void parse_command_line(int argc, char **argv)
{
  int iarg = 1;
  while (iarg < argc) {
    if (argv[iarg][0] != '-')
      break;

    if (strcmp(argv[iarg], "-poly") == 0) {
      print_poly = true;
    }
    else if (strcmp(argv[iarg], "-stat") == 0) {
      print_stat = true;
    }
    else if (strcmp(argv[iarg], "-entry") == 0) {
      iarg++;
      if (iarg >= argc)
	usage_error();

      int i;
      sscanf(argv[iarg], "%d", &i);
      entry.push_back(i);
    };
    iarg++;
  };

  if (iarg + 1 != argc) usage_error();

  if (entry.size() == 0 && !print_poly) {
    // default: print statistics
    print_stat = true; 
  };

  isotable_filename = argv[iarg];
}

void usage_error()
{
  cerr << "Usage: ijktableinfo [-poly] [-stat] [-entry {num}] {isotable file}" 
       << endl;
  exit(10);
}
