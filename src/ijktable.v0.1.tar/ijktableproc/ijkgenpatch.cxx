/// \file ijkgenpatch.cxx
/// generate isosurface patch

/*
  IJK: Isosurface Jeneration Code
  Copyright (C) 2006, 2003, 2001 Rephael Wenger

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public License
  (LGPL) as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

#include <ctype.h>
#include <stdlib.h>
#include <assert.h>

#include "ijktable.h"

using namespace std;
using namespace IJKTABLE;

extern "C" void clarkson_convex_hull
  (int dimension, double * point_coord, int num_points, 
   int * convex_hull_dimension, int ** simplex_vert, int * num_simplices);
extern "C" void free_simplex_vertices(int * simplex_vert);

void ijkgenpatch
  (const ISOSURFACE_TABLE_POLYHEDRON & polyhedron,
   const long code, vector<int> & edge_list, int & num_simplices)
// polyhedron = mesh polyhedron
// code = i'th bit encodes +/- value of i'th polyhedron vertex
// edge_list = return list of polyhedron edges
//   i'th simplex has vertices on edges
//      (edge_list[d*i], edge_list[d*i+1], ..., edge_list[d*i+d-1])
{
  bool * vertex_sign = new bool[polyhedron.NumVertices()];
  bool * bipolar_edge = new bool[polyhedron.NumEdges()];
  num_simplices = 0;
  
  edge_list.erase(edge_list.begin(), edge_list.end());

  // determine vertex signs
  int num_pos_vertices = 0;
  for (int iv = 0; iv < polyhedron.NumVertices(); iv++) {
    vertex_sign[iv] = polyhedron.VertexSign(code, iv);
    if (vertex_sign[iv])
      num_pos_vertices++;
  };

  // determine bipolar edges
  int num_bipolar_edges = 0;
  for (int ie = 0; ie < polyhedron.NumEdges(); ie++) {
    int iv0 = polyhedron.EdgeEndpoint(ie, 0);
    int iv1 = polyhedron.EdgeEndpoint(ie, 1);

    if (vertex_sign[iv0] != vertex_sign[iv1]) {
      bipolar_edge[ie] = true;
      num_bipolar_edges++;
    }
    else
      bipolar_edge[ie] = false;
  };

  int nump = num_pos_vertices+num_bipolar_edges;
  int * point_list = new int[nump];
  double * point_coord = new double[nump*polyhedron.Dimension()];

  int ip = 0;
  for (int jv = 0; jv < polyhedron.NumVertices(); jv++) {
    if (vertex_sign[jv]) {
      for (int ic = 0; ic < polyhedron.Dimension(); ic++) {
	int j = ip*polyhedron.Dimension()+ic;
	point_coord[j] = polyhedron.VertexCoord(jv, ic);
      };

      point_list[ip] = jv;
      ip++;
    };
  };

  for (int je = 0; je < polyhedron.NumEdges(); je++) {
    if (bipolar_edge[je]) {
      // edge connects positive and negative vertex
      // output edge midpoint
      for (int ic = 0; ic < polyhedron.Dimension(); ic++) {
	int j = ip*polyhedron.Dimension()+ic;
	point_coord[j] = polyhedron.MidpointCoord(je, ic);
      };

      point_list[ip] = je;
      ip++;
    };
  };

  assert(ip == nump);

  int * simplex_vert;
  int num_hull_simplices = 0;
  int convex_hull_dimension = 0;
  clarkson_convex_hull(polyhedron.Dimension(), point_coord, nump,
		       &convex_hull_dimension, &simplex_vert, 
		       &num_hull_simplices);

  assert(nump == 0 || convex_hull_dimension == polyhedron.Dimension());

  for (int is = 0; is < num_hull_simplices; is++) {

    bool flag_isosurface_simplex = true;
    for (int ic = 0; ic < polyhedron.Dimension(); ic++)
      if (simplex_vert[is*polyhedron.Dimension()+ic] < num_pos_vertices)
	// ignore simplices sharing a polyhedron vertex
	flag_isosurface_simplex = false;

    // ignore simplices lying on polyhedron facets
    if (flag_isosurface_simplex) {
      long vertex_bits = 0L;
      for (int ic = 0; ic < polyhedron.Dimension(); ic++) {
	int ip = simplex_vert[is*polyhedron.Dimension()+ic];
	assert (ip >= num_pos_vertices);

	int ie = point_list[ip];
	int iv0 = polyhedron.EdgeEndpoint(ie, 0);
	int iv1 = polyhedron.EdgeEndpoint(ie, 1);

	vertex_bits = vertex_bits | (1L << iv0);
	vertex_bits = vertex_bits | (1L << iv1);
      };

      for (int jf = 0; jf < polyhedron.NumFacets(); jf++) {
	FACET f = polyhedron.Facet(jf);
	if ((vertex_bits & (~f)) == 0) {
	  flag_isosurface_simplex = false;
	  break;
	};
      };
    };

    if (flag_isosurface_simplex) {
      for (int ic = 0; ic < polyhedron.Dimension(); ic++) {
	int ip = simplex_vert[is*polyhedron.Dimension()+ic];
	int ie = point_list[ip];
	edge_list.push_back(ie);
      };
      num_simplices++;
    };
  };

  free_simplex_vertices(simplex_vert);

  delete [] point_list;
  delete [] point_coord;
  delete [] bipolar_edge;
  delete [] vertex_sign;
}


// old version
void genisopatchV1
  (const ISOSURFACE_TABLE_POLYHEDRON & polyhedron,
   const long code, vector<int> & edge_list, int & num_simplices)
// polyhedron = mesh polyhedron
// code = i'th bit encodes +/- value of i'th polyhedron vertex
// edge_list = return list of polyhedron edges
//   i'th simplex has vertices on edges
//      (edge_list[d*i], edge_list[d*i+1], ..., edge_list[d*i+d-1])
{
  bool * vertex_sign = new bool[polyhedron.NumVertices()];
  bool * bipolar_edge = new bool[polyhedron.NumEdges()];
  num_simplices = 0;
  
  edge_list.erase(edge_list.begin(), edge_list.end());

  // determine vertex signs
  int num_pos_vertices = 0;
  for (int iv = 0; iv < polyhedron.NumVertices(); iv++) {
    vertex_sign[iv] = polyhedron.VertexSign(code, iv);
    if (vertex_sign[iv])
      num_pos_vertices++;
  };

  // determine bipolar edges
  int num_bipolar_edges = 0;
  for (int ie = 0; ie < polyhedron.NumEdges(); ie++) {
    int iv0 = polyhedron.EdgeEndpoint(ie, 0);
    int iv1 = polyhedron.EdgeEndpoint(ie, 1);

    if (vertex_sign[iv0] != vertex_sign[iv1]) {
      bipolar_edge[ie] = true;
      num_bipolar_edges++;
    }
    else
      bipolar_edge[ie] = false;
  };

  int nump = num_pos_vertices+num_bipolar_edges;
  int * point_list = new int[nump];
  double * point_coord = new double[nump*polyhedron.Dimension()];

  int ip = 0;
  for (int jv = 0; jv < polyhedron.NumVertices(); jv++) {
    if (vertex_sign[jv]) {
      for (int ic = 0; ic < polyhedron.Dimension(); ic++) {
	int j = ip*polyhedron.Dimension()+ic;
	point_coord[j] = polyhedron.VertexCoord(jv, ic);
      };

      point_list[ip] = jv;
      ip++;
    };
  };

  for (int je = 0; je < polyhedron.NumEdges(); je++) {
    if (bipolar_edge[je]) {
      // edge connects positive and negative vertex
      // output edge midpoint
      for (int ic = 0; ic < polyhedron.Dimension(); ic++) {
	int j = ip*polyhedron.Dimension()+ic;
	point_coord[j] = polyhedron.MidpointCoord(je, ic);
      };

      point_list[ip] = je;
      ip++;
    };
  };

  assert(ip == nump);

  int * simplex_vert;
  int num_hull_simplices = 0;
  int convex_hull_dimension = 0;
  clarkson_convex_hull(polyhedron.Dimension(), point_coord, nump,
		       &convex_hull_dimension, &simplex_vert, 
		       &num_hull_simplices);

  assert(nump == 0 || convex_hull_dimension == polyhedron.Dimension());

  for (int is = 0; is < num_hull_simplices; is++) {

    bool flag_isosurface_simplex = true;
    for (int ic = 0; ic < polyhedron.Dimension(); ic++)
      if (simplex_vert[is*polyhedron.Dimension()+ic] < num_pos_vertices)
	flag_isosurface_simplex = false;

    if (flag_isosurface_simplex) {
      for (int ic = 0; ic < polyhedron.Dimension(); ic++) {
	int ip = simplex_vert[is*polyhedron.Dimension()+ic];
	int ie = point_list[ip];
	edge_list.push_back(ie);
      };
      num_simplices++;
    };
  };

  free_simplex_vertices(simplex_vert);

  delete [] point_list;
  delete [] point_coord;
  delete [] bipolar_edge;
  delete [] vertex_sign;
}


