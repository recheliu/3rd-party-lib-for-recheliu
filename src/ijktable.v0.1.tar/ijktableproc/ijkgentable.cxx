/// \file ijkgentable.cxx
/// generate isosurface table

/*
  IJK: Isosurface Jeneration Code
  Copyright (C) 2006, 2003, 2001 Rephael Wenger

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public License
  (LGPL) as published by the Free Software Foundation; either
  version 2.1 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, write to the Free Software
  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include <fstream>
#include <iostream>
#include <sstream>
#include <vector>

#include <ctype.h>
#include <stdio.h>
#include <stdlib.h>

#include "ijktable.h"

using namespace std;
using namespace IJKTABLE;

// types
enum MESH_POLYHEDRON_TYPE { SIMPLEX, CUBE, SPRISM };

// global variables
int dimension = 0;
MESH_POLYHEDRON_TYPE mesh_polyhedron_type = CUBE;
bool verbose = true;
bool old_format = false;
int output_trigger = 5000;
const int MAX_HYPERCUBE_DIMENSION = 4;
const int MAX_SIMPLEX_DIMENSION = 20;

// routines
void parse_command_line(int argc, char **argv);
void check_dimension(const int d, 
		     const MESH_POLYHEDRON_TYPE mesh_poly_type);
void check_num_vertices(const int d,
			const MESH_POLYHEDRON_TYPE mesh_poly_type,
			const int max_numv);

void memory_exhaustion();
void usage_error();
void help_msg();

// external routine
void ijkgenpatch
  (const ISOSURFACE_TABLE_POLYHEDRON & polyhedron,
   const long code, vector<int> & edge_list, int & num_simplices);


int main(int argc, char **argv)
{
  std::set_new_handler(memory_exhaustion);

  try {
    ostringstream isotable_filename;

    parse_command_line(argc, argv);

    if (dimension == 0) {
      cout << "Enter dimension: ";
      cin >> dimension;
    };

    check_dimension(dimension, mesh_polyhedron_type);

    ISOSURFACE_TABLE isotable(dimension);

    check_num_vertices(dimension, mesh_polyhedron_type, 
		       isotable.MaxNumVertices());

    switch(mesh_polyhedron_type) {

    case CUBE:
    default:
      isotable.GenCube(dimension);
      break;

    case SIMPLEX:
      isotable.GenSimplex(dimension);
      break;

    case SPRISM:
      ISOSURFACE_TABLE_POLYHEDRON base_polyhedron(dimension-1), 
	prism(dimension);
      base_polyhedron.GenSimplex(dimension-1);
      generate_prism(base_polyhedron, prism);
      isotable.Set(prism);
      break;
    };

    if (!isotable.Polyhedron().Check()) {
      cerr << "Problem constructing polyhedron." << endl;
      cerr << "Exiting." << endl;
      exit(10);
    };

    if (verbose) {
      cout << isotable.Polyhedron().Dimension() << "D ";
      switch(mesh_polyhedron_type) {

      case SIMPLEX:
	cout << "simplex has ";
	break;

      case CUBE:
	cout << "hypercube has ";
	break;

      case SPRISM:
	cout << "prism with simplex base has ";
	break;
      };

      cout << isotable.Polyhedron().NumVertices()
	   << " vertices and " << isotable.Polyhedron().NumEdges()
	   << " edges." << endl;
      cout << "Isosurface table has " 
	   << isotable.NumTableEntries() << " entries." << endl;
    };

    if (verbose)
      cout << "Generating isosurface table." << endl;

    for (int it = 0; it < isotable.NumTableEntries(); it++) {
      vector<int> edge_list;
      int num_simplices = 0;

      ijkgenpatch(isotable.Polyhedron(), it, edge_list, num_simplices);

      isotable.SetNumSimplices(it, num_simplices);

      for (int is = 0; is < num_simplices; is++) {
	for (int j = 0; j < isotable.Dimension(); j++) {
	  int ie = edge_list[is*isotable.Dimension() + j];
	  isotable.SetSimplexVertex(it, is, j, ie);
	};
      };

      if (verbose && it > 0 && it%output_trigger == 0) {
	cout << "  " << it << " out of " << isotable.NumTableEntries()
	     << " isosurface table entries completed." << endl; 
      };
    };

    if (!isotable.CheckTable()) {
      cerr << "Error detected in isosurface table." << endl;
      cerr << "Exiting." << endl;
      exit(10);
    };

    // generate isosurface table file name
    isotable_filename << "isosurface_table";
    switch (mesh_polyhedron_type) {

    case SIMPLEX:
      isotable_filename << ".s";
      break;

    case SPRISM:
      isotable_filename << ".sprism";
      break;

    case CUBE:
    default:
      isotable_filename << ".c";
      break;
    };

    isotable_filename << "." << isotable.Dimension() << ends; 

    if (verbose)
      cout << "Writing isosurface table to file " 
	   << isotable_filename.str() << "." << endl;

    ofstream isotable_file(isotable_filename.str().c_str(), ios::out);
    if (!old_format) {
      isotable.WriteText(isotable_file);
    }
    else {
      isotable.WriteTextV1(isotable_file);
    };
  }
  catch (ISOSURFACE_TABLE_ERROR error) {
    cerr << "Programming error." << endl;
    cerr << error.Msg() << endl;
    cerr << "Exiting." << endl;
    exit(20);
  };
}


void parse_command_line(int argc, char **argv)
{
  int iarg = 1;
  while (iarg < argc) {
    if (argv[iarg][0] != '-')
      usage_error();
    if (strcmp(argv[iarg], "-d") == 0) {
      iarg++;
      if (iarg >= argc)
	usage_error();

      sscanf(argv[iarg], "%d", &dimension);
    }
    else if (strcmp(argv[iarg], "-V") == 0) {
      verbose = true;
      iarg++;
      if (iarg >= argc)
	usage_error();

      sscanf(argv[iarg], "%d", &output_trigger);
    }
    else if (strcmp(argv[iarg], "-poly") == 0) {
      iarg++;
      if (iarg >= argc)
	usage_error();

      if (strcmp(argv[iarg], "cube") == 0)
	  mesh_polyhedron_type = CUBE;
      else if (strcmp(argv[iarg], "simplex") == 0)
	  mesh_polyhedron_type = SIMPLEX;
      else if (strcmp(argv[iarg], "sprism") == 0)
	  mesh_polyhedron_type = SPRISM;
      else
	usage_error();
    }
    else if (strcmp(argv[iarg], "-old_format") == 0) {
      old_format = true;
    }
    else {
      for (int j = 1; argv[iarg][j] != '\0'; j++) {
	if (argv[iarg][j] == 'c')
	  mesh_polyhedron_type = CUBE;
	else if (argv[iarg][j] == 'h')
	  help_msg();
	else if (argv[iarg][j] == 'q')
	  verbose = false;
	else if (argv[iarg][j] == 's')
	  mesh_polyhedron_type = SIMPLEX;
	else if (argv[iarg][j] == 'v')
	  verbose = true;
	else
	  usage_error();
      };
    };
    iarg++;
  };
}

void check_dimension(const int dimension,
		     const MESH_POLYHEDRON_TYPE mesh_polyhedron_type)
// exit if illegal dimension found
{
  if (dimension < 2) {
    cerr << "Illegal dimension: " << dimension << endl;
    cerr << "Dimension must be at least 2." << endl;
    cerr << "Exiting." << endl;
    exit(10);
  };

  if (mesh_polyhedron_type == CUBE && dimension > MAX_HYPERCUBE_DIMENSION) {
    cerr << "Illegal dimension: " << dimension << endl;
    cerr << "Hypercube dimension is at most " 
	 << MAX_HYPERCUBE_DIMENSION << "." 
	 << endl;
    cerr << "Exiting." << endl;
    exit(10);
  };

  if (mesh_polyhedron_type == SIMPLEX && dimension > MAX_SIMPLEX_DIMENSION) {
    cerr << "Illegal dimension: " << dimension << endl;
    cerr << "Simplex dimension is at most " << MAX_SIMPLEX_DIMENSION << "." 
	 << endl;
    cerr << "Exiting." << endl;
    exit(10);
  };
}

void check_num_vertices(const int d,
			const MESH_POLYHEDRON_TYPE mesh_poly_type,
			const int max_numv)
{
  int numv = 0;
  if (mesh_polyhedron_type == CUBE) {
    numv = (1L << dimension);
  }
  else {
    numv = dimension+1;
  };

  if (numv > max_numv) {
    cerr << "Polyhedron has too many vertices." << endl;
    cerr << d << "D ";
    if (mesh_polyhedron_type == CUBE) {
      cerr << "hypercube ";
    }
    else {
      cerr << "simplex ";
    };
    cerr << "has " << numv << " vertices.  Maximum number of vertices = " 
	 << max_numv << "."
	 << endl;
    cerr << "Exiting." << endl;
    exit(10);
  };
}

void memory_exhaustion()
{
   cerr << "Error: Out of memory.  Terminating program." << endl;
   exit(10);
}

void usage_error()
{
  cerr << "Usage: ijkgentable [-chqsv] [-d <dimension>] [-V <n>]" << endl;
  cout << "                   [-poly {cube|simplex|sprism}] [-old_format]" << endl;
  exit(10);
}

void help_msg()
{
  cout << "ijkgentable - generate isosurface table" << endl;
  cout << "  Generate table of isosurface patches for all +/- vertex sign patterns." << endl;
  cout << "Usage: ijkgentable [-d <dimension>] [-hqv] [-V <n>]" << endl;
  cout << "                   [-poly {cube|simplex|sprism}]" << endl;
  cout << "  -poly cube: Cube polyhedron (default.)" << endl;
  cout << "  -poly simplex: Simplex polyhedron." << endl;
  cout << "  -poly sprism: Prism with simplex base." << endl;
  cout << "  -d <dimension> : Dimension is <dimension>." << endl;
  cout << "  -h : Print this help message (and exit.)" << endl;
  cout << "  -q : Quiet mode." << endl;
  cout << "  -v : Verbose mode (default.)" << endl;
  cout << "  -V <n>: Verbose mode. Output after every <n> table entries." 
       << endl;
  cout << "  -old_format: Old format.  (No facets or headers.)" << endl;
  exit(0);
}
